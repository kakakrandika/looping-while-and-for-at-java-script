var jmlAngkot = 10;
var angkotBeroperasi = 5;
var noAngkot = 1; 

while(noAngkot <= angkotBeroperasi){
	console.log('Angkot No. ' + noAngkot + ' Beroperasi dengan baik');
noAngkot++;
}

for (var noAngkot = angkotBeroperasi +1; noAngkot <= jmlAngkot; noAngkot++) {
	console.log('Angkot No. ' + noAngkot + ' Tidak Beroperasi '
		 );
}
